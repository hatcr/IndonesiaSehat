package com.nanostd.indonesiasehat//package com.nanostd.indonesiasehat
//
data class UserData(
    val id: String = "",
    val emailUser: String = "",
    val password: String = "",
    val daftarNamaUser: String = ""
) {


}